KALLUL-23 — A Little Universe, Just for You

PROJECT FILES
- index.html: website structure and editable text
- style.css: colours, responsive layout, forest/cosmos design, animations
- script.js: interactions, games, collected stars, and grand finale
- images/: place any photos you want to add here

HOW TO TEST
Open index.html in a browser. Keep all three files in the same folder.

HOW TO PUBLISH
Upload index.html, style.css, and script.js to the root of a GitHub repository.
For GitHub Pages, enable Pages in repository Settings and choose the main branch/root.
For Vercel, import the repository and deploy it as a static site; no build command is needed.

PERSONALISE BEFORE SHARING
1. In index.html, replace the sample memory cards in the Memory Moon section with real memories.
2. Edit the sample birthday letter in the Secret Library section so it sounds like you.
3. Add photos into images/ if you want to include pictures. If you do, update the HTML with the matching image paths.

NOTES
- This is a static website; no server or database is required.
- The letter can be opened anytime. The grand finale unlocks after 5 activity stars.
- Google Fonts are loaded online; the site still has fallback fonts if offline.
