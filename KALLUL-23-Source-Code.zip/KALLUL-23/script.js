// KALLUL-23 — all interactive behaviour lives here.
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const sky = $('#sky');
const ambient = $('#ambientFireflies');

// Create the star field and ambient fireflies.
for (let i = 0; i < 115; i++) {
  const star = document.createElement('span');
  star.className = 'star-speck';
  star.style.left = `${Math.random() * 100}%`;
  star.style.top = `${Math.random() * 100}%`;
  star.style.animationDelay = `${Math.random() * 4}s`;
  const size = 1 + Math.random() * 2.2;
  star.style.width = `${size}px`;
  star.style.height = `${size}px`;
  star.style.opacity = `${0.2 + Math.random() * 0.7}`;
  sky.appendChild(star);
}
for (let i = 0; i < 22; i++) {
  const dot = document.createElement('span');
  dot.className = 'ambient-dot';
  dot.style.left = `${Math.random() * 100}%`;
  dot.style.top = `${Math.random() * 100}%`;
  dot.style.animationDelay = `${Math.random() * 6}s`;
  dot.style.animationDuration = `${5 + Math.random() * 7}s`;
  ambient.appendChild(dot);
}

$('#motionToggle').addEventListener('click', () => {
  const isOff = document.body.classList.toggle('no-motion');
  $('#motionToggle').textContent = isOff ? '✦ Motion off' : '✦ Motion on';
  $('#motionToggle').setAttribute('aria-pressed', String(!isOff));
});

$('#enterButton').addEventListener('click', () => {
  $('#welcome').classList.add('hidden');
  $('#universe').classList.remove('hidden');
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

const starRewards = new Set();
const completedPanels = new Set();
const totalStars = 5;
function awardStar(key) {
  if (starRewards.has(key)) return;
  starRewards.add(key);
  updateProgress();
}
function updateProgress() {
  const count = starRewards.size;
  $('#starCount').textContent = `${count} ${count === 1 ? 'star' : 'stars'} collected`;
  $('#progressBar').style.width = `${Math.min(count / totalStars, 1) * 100}%`;
  $('#progressLabel').textContent = count >= totalStars
    ? 'Your constellation is complete. The finale is ready! ✨'
    : `${totalStars - count} more ${totalStars - count === 1 ? 'star' : 'stars'} to unlock the grand finale.`;
  $('#finaleProgress').style.width = `${Math.min(count / totalStars, 1) * 100}%`;
  $('#unlockFinale').disabled = count < totalStars;
}
function completePanel(id) {
  if (completedPanels.has(id)) return;
  completedPanels.add(id);
  const destination = $(`.destination[data-panel="${id}"]`);
  if (destination) destination.classList.add('completed');
}

function openPanel(id) {
  $$('.activity-panel').forEach(panel => panel.classList.remove('active'));
  const panel = document.getElementById(id);
  if (!panel) return;
  panel.classList.add('active');
  panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
$$('.destination').forEach(button => button.addEventListener('click', () => openPanel(button.dataset.panel)));
$$('.close-panel').forEach(button => button.addEventListener('click', () => {
  button.closest('.activity-panel').classList.remove('active');
}));
$$('.destination').forEach(button => button.addEventListener('click', () => {
  if (completedPanels.has(button.dataset.panel)) button.classList.add('completed');
}));

// Firefly Forest
const fireflyMessages = [
  'You deserve little moments of magic, even on ordinary days. ✨',
  'I hope you always make time for the things that make you feel alive. 🌿',
  'A tiny reminder: someone is cheering for you, always. 💛',
  'May this year bring you unexpected adventures and peaceful evenings. 🌙',
  'If I could bottle one wish for you, it would be a year full of happiness. 💗'
];
const fireflyGame = $('#fireflyGame');
const foundFireflies = new Set();
fireflyMessages.forEach((message, index) => {
  const button = document.createElement('button');
  button.className = 'firefly-button';
  button.type = 'button';
  button.textContent = '✦';
  button.setAttribute('aria-label', `Reveal firefly message ${index + 1}`);
  button.addEventListener('click', () => {
    foundFireflies.add(index);
    button.classList.add('found');
    button.textContent = '✨';
    $('#fireflyMessage').textContent = `${message}${foundFireflies.size === fireflyMessages.length ? ' You found all five! The forest is glowing for you. 🌟' : ''}`;
    if (foundFireflies.size === fireflyMessages.length) {
      awardStar('fireflies'); completePanel('fireflies');
    }
  });
  fireflyGame.appendChild(button);
});

// Wildwood
const woodMessages = {
  rain: 'Rain tapping on leaves, a warm shelter, and nowhere you need to rush. May you always find rest when you need it. 🌧️',
  sun: 'A meadow full of tiny flowers, sunshine, and a whole day to explore. May your year bring you bright beginnings. 🌼',
  moon: 'A quiet lake reflecting the moon, with fireflies dancing beside the water. May peace always find its way to you. 🌙'
};
$$('[data-wood]').forEach(button => button.addEventListener('click', () => {
  const kind = button.dataset.wood;
  $('#wildwoodMessage').textContent = woodMessages[kind];
  const scenes = { rain: '🌲　🌧️　🍄　🌿', sun: '🌼　🌳　🦋　🌻', moon: '🌙　🌲　✨　🌊' };
  $('#natureScene').textContent = scenes[kind];
  awardStar('wildwood'); completePanel('wildwood');
}));

// Memory Moon is intentionally a sample section; personalise the memory cards in index.html.
$('#memory').addEventListener('click', event => {
  if (event.target.closest('.memory-card')) {
    $$('.memory-card').forEach(card => card.classList.remove('selected'));
    event.target.closest('.memory-card').classList.add('selected');
    awardStar('memory'); completePanel('memory');
  }
});
$$('.memory-card').forEach(card => card.addEventListener('click', () => {
  $$('.memory-card').forEach(item => item.style.borderColor = '#ffffff20');
  card.style.borderColor = '#ffe79a99';
  awardStar('memory'); completePanel('memory');
}));

// Star puzzle: tap 1, 2, then 3.
let nextStar = 1;
const tappedStars = [];
function resetStarPuzzle() {
  nextStar = 1; tappedStars.length = 0;
  $$('.puzzle-star').forEach(button => button.classList.remove('done'));
  $('#constellationLine').setAttribute('d', '');
  $('#starMessage').textContent = 'The constellation is waiting…';
}
$$('.puzzle-star').forEach(button => button.addEventListener('click', () => {
  const number = Number(button.dataset.number);
  if (number !== nextStar) {
    resetStarPuzzle();
    $('#starMessage').textContent = 'Almost! Start again with Star 1. ⭐';
    return;
  }
  button.classList.add('done');
  tappedStars.push(number);
  nextStar += 1;
  if (tappedStars.length === 1) $('#constellationLine').setAttribute('d', 'M 50 65');
  if (tappedStars.length === 2) $('#constellationLine').setAttribute('d', 'M 50 65 L 150 28');
  if (tappedStars.length === 3) {
    $('#constellationLine').setAttribute('d', 'M 50 65 L 150 28 L 250 78');
    $('#starMessage').textContent = 'Constellation complete! Your next year is full of stars waiting to be discovered. 💫';
    awardStar('stars'); completePanel('stars');
  } else {
    $('#starMessage').textContent = `Good! Now find star ${nextStar}.`;
  }
}));
$('#resetStars').addEventListener('click', resetStarPuzzle);

// Birthday tree
let treeStage = 0;
const treeStages = ['🌱', '🌿', '🌳', '🌳🌸', '🌳🌸✨'];
$('#waterTree').addEventListener('click', () => {
  treeStage = Math.min(treeStage + 1, treeStages.length - 1);
  $('#birthdayTreeEmoji').textContent = treeStages[treeStage];
  $('#birthdayTreeEmoji').classList.toggle('bloom', treeStage >= 4);
  $('#treeMessage').textContent = treeStage === 4
    ? 'Look at it bloom! May your 23rd year grow into something beautiful. 🌸'
    : 'A little more care, a little more growth. 💧';
  if (treeStage === 4) { awardStar('birthdayTree'); completePanel('birthdayTree'); }
});

// Cake Studio
$$('[data-topping]').forEach(button => button.addEventListener('click', () => {
  $('#cakeDisplay').textContent = `🎂 ${button.dataset.topping}${button.dataset.topping}`;
  $('#cakeMessage').textContent = 'Chef Kallul’s birthday cake is ready! Make a wish. 💛';
  awardStar('cake'); completePanel('cake');
}));

// Badminton tap challenge
let badmintonScore = 0;
let badmintonSeconds = 10;
let badmintonInterval = null;
let badmintonPlaying = false;
function finishBadminton() {
  clearInterval(badmintonInterval);
  badmintonPlaying = false;
  $('#hitShuttle').disabled = true;
  $('#badmintonMessage').textContent = `Time! You made ${badmintonScore} taps. Champion energy! 🏆`;
  awardStar('badminton'); completePanel('badminton');
}
$('#startBadminton').addEventListener('click', () => {
  clearInterval(badmintonInterval);
  badmintonScore = 0; badmintonSeconds = 10; badmintonPlaying = true;
  $('#badmintonScore').textContent = '0';
  $('#badmintonTimer').textContent = '10 seconds';
  $('#hitShuttle').disabled = false;
  $('#badmintonMessage').textContent = 'Go, go, go! 🏸';
  badmintonInterval = setInterval(() => {
    badmintonSeconds -= 1;
    $('#badmintonTimer').textContent = `${badmintonSeconds} seconds`;
    if (badmintonSeconds <= 0) finishBadminton();
  }, 1000);
});
$('#hitShuttle').addEventListener('click', () => {
  if (!badmintonPlaying) return;
  badmintonScore += 1;
  $('#badmintonScore').textContent = String(badmintonScore);
});

// Envelope opens a letter on a magical book page.
$('#openEnvelope').addEventListener('click', () => {
  $('#openEnvelope').classList.add('open');
  $('#bookPage').classList.remove('hidden');
  $('#openEnvelope').setAttribute('aria-label', 'Birthday envelope opened');
  awardStar('letter'); completePanel('letter');
});

// Secret door
$$('.quiz-answer').forEach(button => button.addEventListener('click', () => {
  const correct = button.dataset.correct === 'true';
  $('#quizMessage').textContent = correct
    ? 'The secret door opens! ✨ Your dreams deserve a whole universe of possibilities. 💛'
    : 'Not quite—try the answer that celebrates your dreams. 🌟';
  if (correct) { awardStar('secretDoor'); completePanel('secretDoor'); }
}));

// Finale
$('#unlockFinale').addEventListener('click', () => {
  if (starRewards.size < totalStars) return;
  $('#finale').classList.remove('hidden');
  $('#finale').scrollIntoView({ behavior: 'smooth', block: 'center' });
  for (let i = 0; i < 30; i++) {
    const sparkle = document.createElement('span');
    sparkle.className = 'finale-sparkle';
    sparkle.textContent = ['✦', '✧', '✨'][i % 3];
    sparkle.style.left = `${Math.random() * 100}%`;
    sparkle.style.top = `${Math.random() * 100}%`;
    $('#finale').appendChild(sparkle);
  }
});
$('#backToGarden').addEventListener('click', () => {
  $('#finale').classList.add('hidden');
  $('#universe').scrollIntoView({ behavior: 'smooth' });
});
